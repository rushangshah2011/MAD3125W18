package com.rs.thunder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity implements View.OnClickListener{
Button btnLogin;
Button btnReg;
EditText uname;
EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    btnLogin = (Button) findViewById(R.id.button2);
    btnLogin.setOnClickListener(this);

    btnReg = (Button) findViewById(R.id.button3);
btnReg.setOnClickListener(this);
   uname = (EditText) findViewById(R.id.uname);

        pass = (EditText) findViewById(R.id.pass);
    }


    @Override
    public void onClick(View view) {
    if(view.getId() == btnLogin.getId()){
        String user = uname.getText().toString();
        String p = pass.getText().toString();

        Toast.makeText(this, "username : " + user + " Password :" + p , Toast.LENGTH_SHORT).show();

    }
    else if(view.getId() == btnReg.getId()){
        Toast.makeText(this, "Dont click me I am busy :)", Toast.LENGTH_SHORT).show();

    }
    }
}
